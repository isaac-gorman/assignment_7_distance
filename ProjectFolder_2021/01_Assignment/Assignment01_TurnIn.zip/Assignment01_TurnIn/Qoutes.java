// ------------------------------
// Programmer:    Isaac Gorman Uribe
// Course:        COSC 1336 Section 006
// Semester:      Spring 2021
// Assignment #:  1a
// Due Date:      February 4, 2021
// ------------------------------

public class Qoutes {
	
	public static void main(String[] args) {
		System.out.println("To be,");
		System.out.println(" or not to be,");
		System.out.println(" that is the question.");
		System.out.println();
		System.out.println("Or perhaps,");
		System.out.println("\tI should be asking,");
		System.out.println("\tsome other question!\n");
		System.out.println("This program was written by Isaac Gorman.");
		System.out.println("End of program.");
	} // end method main 

} // end class FirstJavaProgram
